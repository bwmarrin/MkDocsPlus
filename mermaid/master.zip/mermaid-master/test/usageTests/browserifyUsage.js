/**
 * Created by knut on 14-12-02.
 */
mermaid = require('mermaid');

console.log('Test page! mermaid version'+mermaid.version());
